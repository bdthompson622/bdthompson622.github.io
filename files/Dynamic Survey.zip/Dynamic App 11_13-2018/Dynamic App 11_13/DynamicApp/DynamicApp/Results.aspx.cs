﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DynamicApp
{
    public partial class Results : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Survey masterSurvey = Session["survey"] as Survey;

            //Calculate scores
            masterSurvey.calculate();

            //Display scores
            AppSciCell.Text = masterSurvey.results.score[0].ToString();
            ArtCell.Text = masterSurvey.results.score[1].ToString();
            BusAdmCell.Text = masterSurvey.results.score[2].ToString();
            FinArtCell.Text = masterSurvey.results.score[3].ToString();
            MusCell.Text = masterSurvey.results.score[4].ToString();
            ProStuCell.Text = masterSurvey.results.score[5].ToString();
            SciCell.Text = masterSurvey.results.score[6].ToString();
            EduCell.Text = masterSurvey.results.score[7].ToString();
            NurCell.Text = masterSurvey.results.score[8].ToString();
            SocWorCell.Text = masterSurvey.results.score[9].ToString();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}