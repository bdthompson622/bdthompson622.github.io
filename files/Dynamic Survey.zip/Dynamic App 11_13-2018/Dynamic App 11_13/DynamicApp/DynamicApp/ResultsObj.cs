﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicApp
{
    public class ResultsObj
    {
        public ResultsObj()
        {
            score = new int[10];
            savedAns = new List<bool[]>();

            for (int i = 0; i < 10; i++)
            {
                score[i] = 0;
            }
        }

        public List<bool[]> savedAns;
        public int[] score;
    }
}