﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicApp
{
    public class Survey
    {
        public Survey ()
        {
            questionList = new List<Question>();
            results = new ResultsObj();

            currentQuestion = 0;
        }

        public List<Question> questionList;
        public ResultsObj results;

        public int currentQuestion;

        enum Major {AppSci, Art, BusAdm, FinArt, Mus, ProStu, Sci, Edu, Nur, SocWor}; 

        //Calculation function
        public void calculate()
        {
            for (int i = 0; i < questionList.Count; i++) //for each question
            {
                for (int j = 0; j < 10; j++) //for each answer
                {
                    if (results.savedAns[i][j] == true) results.score[questionList[i].correlation[j]] += 1;
                }
            }
        }
    }
}