﻿CREATE TABLE [dbo].[Questions]
(
	[Id] INT NOT NULL PRIMARY KEY DEFAULT newid(), 
    [question] TEXT NOT NULL, 
    [answer1] TEXT NOT NULL, 
    [answer2] TEXT NOT NULL, 
    [answer3] TEXT NOT NULL, 
    [answer4] TEXT NOT NULL, 
    [answer5] TEXT NOT NULL, 
    [answer6] TEXT NOT NULL, 
    [answer7] TEXT NOT NULL, 
    [answer8] TEXT NOT NULL, 
    [answer9] TEXT NOT NULL, 
    [answer10] TEXT NOT NULL
)
