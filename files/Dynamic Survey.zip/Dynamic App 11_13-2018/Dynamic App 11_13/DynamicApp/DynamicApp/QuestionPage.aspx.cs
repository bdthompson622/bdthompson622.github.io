﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DynamicApp
{
    public partial class QuestionPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Grab the survey
            Survey masterSurvey = Session["survey"] as Survey;

            //Initialization
            if (!IsPostBack)
            {
                //Database Interface
                SurveyDatabaseEntities db = new SurveyDatabaseEntities();
                
                //database object variable
                var questionDB = db.Questions;

                //Loop through the database
                foreach (var question in questionDB)
                {
                    //Temp question object to add to survey question list
                    Question myQuestion = new Question();

                    myQuestion.question = question.question; //The question

                    myQuestion.answers[0] = question.answer1;  //The answers
                    myQuestion.answers[1] = question.answer2;
                    myQuestion.answers[2] = question.answer3;
                    myQuestion.answers[3] = question.answer4;
                    myQuestion.answers[4] = question.answer5;
                    myQuestion.answers[5] = question.answer6;
                    myQuestion.answers[6] = question.answer7;
                    myQuestion.answers[7] = question.answer8;
                    myQuestion.answers[8] = question.answer9;
                    myQuestion.answers[9] = question.answer10;

                    myQuestion.correlation[0] = question.corr1;
                    myQuestion.correlation[1] = question.corr2;
                    myQuestion.correlation[2] = question.corr3;
                    myQuestion.correlation[3] = question.corr4;
                    myQuestion.correlation[4] = question.corr5;
                    myQuestion.correlation[5] = question.corr6;
                    myQuestion.correlation[6] = question.corr7;
                    myQuestion.correlation[7] = question.corr8;
                    myQuestion.correlation[8] = question.corr9;
                    myQuestion.correlation[9] = question.corr10;

                    masterSurvey.questionList.Add(myQuestion);
                }

                //Populate question and checkbox list from survey object
                questionLabel.Text = masterSurvey.questionList[masterSurvey.currentQuestion].question;

                for (int i = 0; i < 10; i++)
                    answerBox.Items[i].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[i];

                /*
                answerBox.Items[0].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[0];
                answerBox.Items[1].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[1];
                answerBox.Items[2].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[2];
                answerBox.Items[3].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[3];
                answerBox.Items[4].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[4];
                answerBox.Items[5].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[5];
                answerBox.Items[6].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[6];
                answerBox.Items[7].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[7];
                answerBox.Items[8].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[8];
                answerBox.Items[9].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[9];
                */

                //Set button data
                back.Enabled = false;

                Session["survey"] = masterSurvey;
                //CreateQuestionTable(answerTable, myQuestion); //Legacy code
            }
        }

        protected void back_Click(object sender, EventArgs e)
        {
            next.Text = "Next";

            Survey masterSurvey = Session["survey"] as Survey;

            //Record checkboxes
            bool[] currentBoxSelect = new bool[10];
            
            //init
            for (int i = 0; i < 10; i++)
                currentBoxSelect[i] = answerBox.Items[i].Selected;

            /*
            currentBoxSelect[0] = answerBox.Items[0].Selected;
            currentBoxSelect[1] = answerBox.Items[1].Selected;
            currentBoxSelect[2] = answerBox.Items[2].Selected;
            currentBoxSelect[3] = answerBox.Items[3].Selected;
            currentBoxSelect[4] = answerBox.Items[4].Selected;
            currentBoxSelect[5] = answerBox.Items[5].Selected;
            currentBoxSelect[6] = answerBox.Items[6].Selected;
            currentBoxSelect[7] = answerBox.Items[7].Selected;
            currentBoxSelect[8] = answerBox.Items[8].Selected;
            currentBoxSelect[9] = answerBox.Items[9].Selected;
            */

            if (masterSurvey.currentQuestion < masterSurvey.results.savedAns.Count())
                masterSurvey.results.savedAns[masterSurvey.currentQuestion] = currentBoxSelect;
            else masterSurvey.results.savedAns.Add(currentBoxSelect);
            
            //Update currentQuestion
            masterSurvey.currentQuestion -= 1;

            //Populate question and checkbox list from survey object
            questionLabel.Text = masterSurvey.questionList[masterSurvey.currentQuestion].question;

            for (int i = 0; i < 10; i++)
                answerBox.Items[i].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[i];
            /*
            answerBox.Items[0].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[0];
            answerBox.Items[1].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[1];
            answerBox.Items[2].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[2];
            answerBox.Items[3].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[3];
            answerBox.Items[4].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[4];
            answerBox.Items[5].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[5];
            answerBox.Items[6].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[6];
            answerBox.Items[7].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[7];
            answerBox.Items[8].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[8];
            answerBox.Items[9].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[9];
            */

            if (masterSurvey.currentQuestion == 0) back.Enabled = false;

            //Set checkbox status
            currentBoxSelect = masterSurvey.results.savedAns[masterSurvey.currentQuestion];

            for (int i = 0; i < 10; i++)
                answerBox.Items[i].Selected = currentBoxSelect[i];
            /*
            answerBox.Items[0].Selected = currentBoxSelect[0];
            answerBox.Items[1].Selected = currentBoxSelect[1];
            answerBox.Items[2].Selected = currentBoxSelect[2];
            answerBox.Items[3].Selected = currentBoxSelect[3];
            answerBox.Items[4].Selected = currentBoxSelect[4];
            answerBox.Items[5].Selected = currentBoxSelect[5];
            answerBox.Items[6].Selected = currentBoxSelect[6];
            answerBox.Items[7].Selected = currentBoxSelect[7];
            answerBox.Items[8].Selected = currentBoxSelect[8];
            answerBox.Items[9].Selected = currentBoxSelect[9];
            */

            Session["survey"] = masterSurvey;
        }

        protected void next_Click(object sender, EventArgs e)
        {
            Survey masterSurvey = Session["survey"] as Survey;

            //Record checkboxes
            bool[] currentBoxSelect = new bool[10];
            //init
            for (int i = 0; i < 10; i++)
                currentBoxSelect[i] = answerBox.Items[i].Selected;
            /*
            currentBoxSelect[0] = answerBox.Items[0].Selected;
            currentBoxSelect[1] = answerBox.Items[1].Selected;
            currentBoxSelect[2] = answerBox.Items[2].Selected;
            currentBoxSelect[3] = answerBox.Items[3].Selected;
            currentBoxSelect[4] = answerBox.Items[4].Selected;
            currentBoxSelect[5] = answerBox.Items[5].Selected;
            currentBoxSelect[6] = answerBox.Items[6].Selected;
            currentBoxSelect[7] = answerBox.Items[7].Selected;
            currentBoxSelect[8] = answerBox.Items[8].Selected;
            currentBoxSelect[9] = answerBox.Items[9].Selected;
            */

            if (masterSurvey.currentQuestion < masterSurvey.results.savedAns.Count())
                masterSurvey.results.savedAns[masterSurvey.currentQuestion] = currentBoxSelect;
            else masterSurvey.results.savedAns.Add(currentBoxSelect);

            //Is it the last question?
            if (masterSurvey.currentQuestion == masterSurvey.questionList.Count - 1)
            {
                Session["survey"] = masterSurvey;

                Response.Redirect("Results.aspx");
            }
            //Update currentQuestion
            else
            {
                masterSurvey.currentQuestion += 1;

                back.Enabled = true;

                //Populate question and checkbox list from survey object
                questionLabel.Text = masterSurvey.questionList[masterSurvey.currentQuestion].question;

                for (int i = 0; i < 10; i++)
                    answerBox.Items[i].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[i];
                /*
                answerBox.Items[0].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[0];
                answerBox.Items[1].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[1];
                answerBox.Items[2].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[2];
                answerBox.Items[3].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[3];
                answerBox.Items[4].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[4];
                answerBox.Items[5].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[5];
                answerBox.Items[6].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[6];
                answerBox.Items[7].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[7];
                answerBox.Items[8].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[8];
                answerBox.Items[9].Text = masterSurvey.questionList[masterSurvey.currentQuestion].answers[9];
                */

                if (masterSurvey.currentQuestion == masterSurvey.questionList.Count - 1) next.Text = "Submit";

                //Set checkbox status
                if (masterSurvey.currentQuestion < masterSurvey.results.savedAns.Count())
                {
                    currentBoxSelect = masterSurvey.results.savedAns[masterSurvey.currentQuestion];

                    for (int i = 0; i < 10; i++)
                        answerBox.Items[i].Selected = currentBoxSelect[i];

                    /*
                    answerBox.Items[0].Selected = currentBoxSelect[0];
                    answerBox.Items[1].Selected = currentBoxSelect[1];
                    answerBox.Items[2].Selected = currentBoxSelect[2];
                    answerBox.Items[3].Selected = currentBoxSelect[3];
                    answerBox.Items[4].Selected = currentBoxSelect[4];
                    answerBox.Items[5].Selected = currentBoxSelect[5];
                    answerBox.Items[6].Selected = currentBoxSelect[6];
                    answerBox.Items[7].Selected = currentBoxSelect[7];
                    answerBox.Items[8].Selected = currentBoxSelect[8];
                    answerBox.Items[9].Selected = currentBoxSelect[9];
                    */
                }
                else
                {
                    for (int i = 0; i < 10; i++) answerBox.Items[i].Selected = false;
                }

                Session["survey"] = masterSurvey;
            }
        }

        /* Legacy table creation. New method uses checkboxList
        public void CreateQuestionTable(Table myTable, Question question)
        {
            TableRow questionRow = new TableRow();
            TableCell questionCell = new TableCell();
            Label qText = new Label();
            qText.Text = question.question;
            questionCell.Controls.Add(qText);
            questionRow.Controls.Add(questionCell);
            myTable.Controls.Add(questionRow);

            for (int i = 0; i < 10; i++)
            {
                TableRow aRow = new TableRow();
                TableCell answerCell = new TableCell();
                CheckBox aBox = new CheckBox();
                aBox.Text = question.answers[i];
                answerCell.Controls.Add(aBox);
                aRow.Controls.Add(answerCell);
                myTable.Controls.Add(aRow);
            }
        }*/
    }
}